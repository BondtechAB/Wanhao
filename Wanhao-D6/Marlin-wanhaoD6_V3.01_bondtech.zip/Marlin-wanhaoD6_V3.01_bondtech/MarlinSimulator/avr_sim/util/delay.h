#ifndef _SIM_DELAY_H
#define _SIM_DELAY_H

static inline void _delay_ms(int delay) {}
static inline void _delay_us(int delay) {}

#endif//_SIM_DELAY_H
