#ifndef ELECTRONICS_TEST_H
#define ELECTRONICS_TEST_H

//Start the electronics test environment. This environment never returns and disables all other features.
void run_electronics_test();

#endif//ELECTRONICS_TEST_H
